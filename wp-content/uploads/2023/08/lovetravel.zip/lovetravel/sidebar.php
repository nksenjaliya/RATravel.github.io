<div class="nicdark_section nicdark_sidebar">
	<?php dynamic_sidebar( 'nicdark_sidebar' ); ?>
</div>