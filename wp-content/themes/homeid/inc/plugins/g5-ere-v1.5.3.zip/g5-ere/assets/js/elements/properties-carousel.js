(function ($) {
	'use strict';
	var G5ERE_Property_Carousel_Handler = function ($scope, $) {
		G5CORE.util.slickSlider($scope);
		new G5CORE_Animation($scope);
	};
	window.addEventListener( 'elementor/frontend/init', () => {
		elementorFrontend.hooks.addAction('frontend/element_ready/g5-properties-carousel.default', G5ERE_Property_Carousel_Handler);
	});

})(jQuery);