<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
/**
 * @var $property_identity
 */
?>
<span class="g5ere__property-identity"><?php echo esc_html($property_identity)?></span>
