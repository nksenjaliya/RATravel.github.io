<?php
/**
 * @var $title
 */
?>
<h2 class="g5ere__agency-title"><?php echo esc_html($title) ?></h2>
