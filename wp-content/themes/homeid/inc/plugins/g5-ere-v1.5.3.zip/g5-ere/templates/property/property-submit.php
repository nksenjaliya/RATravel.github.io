<?php
/**
 * @var $form
 * @var $action
 * @var $property_id
 * @var $submit_button_text
 * @var $step
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}
$allow_submit = ere_allow_submit();
if ( ! $allow_submit ) {
	echo ere_get_template_html( 'global/access-denied.php', array( 'type' => 'not_allow_submit' ) );
	return;
}
global $property_data, $property_meta_data, $hide_property_fields, $current_user;
$hide_property_fields = ere_get_option( 'hide_property_fields', array() );
if ( ! is_array( $hide_property_fields ) ) {
	$hide_property_fields = array();
}
if ( $form == 'edit-property' ) {
	$property_data      = get_post( $property_id );
	$property_meta_data = get_post_custom( $property_data->ID );
} else {
	$paid_submission_type = ere_get_option( 'paid_submission_type', 'no' );
	if ( $paid_submission_type == 'per_package' ) {
		wp_get_current_user();
		$user_id              = $current_user->ID;
		$ere_profile          = new ERE_Profile();
		$check_package        = $ere_profile->user_package_available( $user_id );
		$select_packages_link = ere_get_permalink( 'packages' );
		if ( $check_package == 0 ) {
			print '<div class="ere-message alert alert-warning" role="alert">' . esc_html__( 'You are not yet subscribed to a listing! Before you can list a property, you must select a listing package. Click the button below to select a listing package.', 'g5-ere' ) . ' </div>
                   <a class="btn btn-default" href="' . $select_packages_link . '">' . esc_html__( 'Get a Listing Package', 'g5-ere' ) . '</a>';

			return;
		} elseif ( $check_package == - 1 ) {
			print '<div class="ere-message alert alert-warning" role="alert">' . esc_html__( 'Your current listing package has expired! Please click the button below to select a new listing package.', 'g5-ere' ) . '</div>
                   <a class="btn btn-default" href="' . $select_packages_link . '">' . esc_html__( 'Upgrade Listing Package', 'g5-ere' ) . '</a>';

			return;
		} elseif ( $check_package == - 2 ) {
			print '<div class="ere-message alert alert-warning" role="alert">' . esc_html__( 'Your current listing package doesn\'t allow you to publish any more properties! Please click the button below to select a new listing package.', 'g5-ere' ) . '</div>
                   <a class="btn btn-default" href="' . $select_packages_link . '">' . esc_html__( 'Upgrade Listing Package', 'g5-ere' ) . '</a>';

			return;
		}
	}
}
wp_enqueue_script( 'plupload' );
wp_enqueue_script( 'jquery-ui-sortable' );
wp_enqueue_script( ERE_PLUGIN_PREFIX . 'property' );
wp_enqueue_script( ERE_PLUGIN_PREFIX . 'property_steps' );
wp_print_styles( ERE_PLUGIN_PREFIX . 'submit-property' );
?>
<section class="ere-property-multi-step">
	<?php
	$layout = ere_get_option( 'property_form_sections', array(
		'title_des' => 'title_des',
		'location'  => 'location',
		'type'      => 'type',
		'price'     => 'price',
		'features'  => 'features',
		'details'   => 'details',
		'media'     => 'media',
		'floors'    => 'floors',
		'contact'   => 'contact'
	) );
	if ( ! in_array( "private_note", $hide_property_fields ) ) {
		$layout['private_note'] = 'private_note';
	}
	unset( $layout['sort_order'] );
	$keys  = array_keys( $layout );
	$total = count( $keys );
	?>
    <nav class="nav nav-pills ere-steps">
		<?php
		$i         = 0;
		$step_name = '';
		foreach ( $layout as $value ):
			$i ++;
			switch ( $value ) {
				case 'title_des':
					$step_name = esc_html__( 'Title & Description', 'g5-ere' );
					break;
				case 'location':
					$step_name = esc_html__( 'Location', 'g5-ere' );
					break;
				case 'type':
					$step_name = esc_html__( 'Type', 'g5-ere' );
					break;
				case 'price':
					$step_name = esc_html__( 'Price', 'g5-ere' );
					break;
				case 'features':
					$step_name = esc_html__( 'Features', 'g5-ere' );
					break;
				case 'details':
					$step_name = esc_html__( 'Details', 'g5-ere' );
					break;
				case 'media':
					$step_name = esc_html__( 'Media', 'g5-ere' );
					break;
				case 'floors':
					$step_name = esc_html__( 'Floors', 'g5-ere' );
					break;
				case 'contact':
					$step_name = esc_html__( 'Contact', 'g5-ere' );
					break;
				case 'private_note':
					$step_name = esc_html__( 'Private Note', 'g5-ere' );
					break;
			}
			?>
            <button class="nav-link mr-2 mb-2 btn<?php if ( $i == 1 ) {
				echo ' active';
			} ?>" type="button" disabled><span
                        class="number"><?php echo esc_html($i)?>.</span> <?php echo esc_html( $step_name ); ?></button>

		<?php endforeach; ?>
    </nav>
    <form action="<?php echo esc_url( $action ); ?>" method="post" id="submit_property_form"
          class="property-manager-form"
          enctype="multipart/form-data">
		<?php do_action( 'ere_before_submit_property' );

		foreach ( $layout as $key => $value ) {
			$index    = array_search( $value, $keys );
			$prev_key = $next_key = '';
			if ( $index > 0 ) {
				$prev_key = $keys[ $index - 1 ];
			}
			if ( $index < $total - 1 ) {
				$next_key = $keys[ $index + 1 ];
			}

			?>
            <fieldset tabindex="-1" id="step-<?php echo esc_attr( $value ); ?>">
				<?php
				ere_get_template( 'property/' . $form . '/' . $value . '.php' );
				?>

                <div class="ere-step-nav border-top-0">
					<?php
					if ( $prev_key != '' ):?>
                        <button class="ere-btn-prev btn btn-outline btn-primary"
                                aria-controls="step-<?php echo esc_attr( $prev_key ); ?>"
                                type="button" title="<?php esc_attr_e( 'Previous', 'g5-ere' ) ?>">
                            <i class="fal fa-long-arrow-left"></i>
                            <span><?php esc_html_e( 'Previous', 'g5-ere' ) ?></span>
                        </button>
					<?php endif; ?>
					<?php $is_show_all = G5ERE()->options()->get_option( 'dashboard_enable_show_all' );
					if ( $is_show_all == 'yes' ):
						?>
                        <button class="ere-btn-edit btn btn-accent" type="button"
                                title="<?php esc_attr_e( 'Show All Fields', 'g5-ere' ) ?>"><?php esc_html_e( 'Show All', 'g5-ere' ) ?></button>
					<?php endif; ?>
					<?php if ( $next_key != '' ): ?>
                        <button class="ere-btn-next btn btn-accent"
                                aria-controls="step-<?php echo esc_attr( $next_key ); ?>"
                                type="button" title="<?php esc_attr_e( 'Next', 'g5-ere' ) ?>">
                            <span><?php esc_html_e( 'Next', 'g5-ere' ) ?></span><i
                                    class="fal fa-long-arrow-right"></i></button>
					<?php else: ?>
                        <input type="submit" name="submit_property" class="button btn-submit-property"
                               value="<?php echo esc_attr( $submit_button_text ); ?>"/>
					<?php endif; ?>
                </div>
            </fieldset>
			<?php
		}
		do_action( 'ere_after_submit_property' ); ?>
		<?php wp_nonce_field( 'ere_submit_property_action', 'ere_submit_property_nonce_field' ); ?>
        <input type="hidden" name="property_form" value="<?php echo esc_attr( $form ); ?>"/>
        <input type="hidden" name="property_action" value="<?php echo esc_attr( $action ) ?>"/>
        <input type="hidden" name="property_id" value="<?php echo esc_attr( $property_id ); ?>"/>
        <input type="hidden" name="step" value="<?php echo esc_attr( $step ); ?>"/>
    </form>
</section>