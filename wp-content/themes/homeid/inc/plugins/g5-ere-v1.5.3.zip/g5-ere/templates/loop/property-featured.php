<?php
// Do not allow directly accessing this file.
if ( ! defined( 'ABSPATH' ) ) {
	exit( 'Direct script access denied.' );
}
?>
<span class="g5ere__property-badge g5ere__featured">
	<?php esc_html_e('Featured','g5-ere') ?>
</span>
